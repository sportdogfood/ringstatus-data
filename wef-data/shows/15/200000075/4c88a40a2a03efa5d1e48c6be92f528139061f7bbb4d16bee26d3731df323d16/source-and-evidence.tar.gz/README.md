# wef-data — live linked collection proof

October 24, 2026. **PASS for the isolated source → linked Airtable collection and bounded adaptive-refresh proof.**

Target: [wef-data](https://airtable.com/appdl16HJ5ETm8N69), base `appdl16HJ5ETm8N69`.
This is an Airtable base; the Outlook mention did not cause any email action.

The [full implementation and schema reference](../../docs/wef-data-implementation-20261024.md)
documents the complete field dictionary, stable keys, relationships, source
contracts, algorithms, actual execution history, verification and remaining limits.

## What was executed

Created 19 populated tables and their fields, then collected fresh data from the
existing `wef-schedules-decoded` routes in show → day → ring → class order.
Every non-break source class was included, without a tenant filter. Source
responses were validated, normalized, upserted by stable keys, and linked using
actual Airtable record IDs. All 3,903 records and authored values/relationships
passed independent readback; verification receipts were subsequently marked and
read back separately.

The original `meta` table and its three empty placeholder rows were preserved.
Existing WEF production tasks, Workers, tenant bases, publishing and WEC workflows
were not changed. No credentials or authentication tokens were written into this
base or the source captures.

## Verified table counts

| Table | Records |
|---|---:|
| runs | 2 |
| shows | 1 |
| days | 4 |
| rings | 24 |
| groups | 157 |
| classes | 204 |
| schedules | 242 |
| horses | 238 |
| riders | 185 |
| trainers | 93 |
| owners | 187 |
| entries | 238 |
| trips | 794 |
| lanes | 7 |
| work-items | 204 |
| slots | 31 |
| collections | 261 |
| requests | 237 |
| results | 794 |
| **Total populated proof records** | **3,903** |

The show was **2026 ESP Fall III (#261901), 200000075**, October 22–25.
Cold source collection took **171.0034 seconds**, with
209 source requests, 3,253,646 response bytes and zero source/identity/
count errors. This timing excludes schema construction, Airtable writes and
readback. It must not be presented as full persistence latency.

Source relationships retained include 24 dated rings, 157 source groups,
242 schedule occurrences (including breaks and repeated group appearances),
204 unique class details, 238 entry identities, 794 class trips, and linked
horse/rider/trainer/owner identities. Every trip has a result-field projection.
A result projection preserves source scores/times/faults/placing and blank/zero
values; it does not assert that an official result was published.

A source class may appear in several schedule groups. Both schedule records and
all group links are preserved while its class detail is fetched once per ring/
date. The baseline deduplicated 10 such extra source occurrences. Names are not
used to merge entity identities. When an owner ID is absent, a source-occurrence
key is explicit and is not presented as an invented numeric owner ID.

`classes.source-json` preserves the sanitized full class response, including
related metadata, order-of-go and phase/team sections. `trips.source-json`
preserves each complete trip payload. `results` exposes its result values as
separate fields and retains a result JSON projection. Missing values remain
missing; no horse/rider profile endpoints or undocumented identities were invented.

## Adaptive lanes and slots — actual bounded execution

The isolated planner evaluated the completed inventory and produced 204 work
items across trial coverage lanes. Trial policy values are visible in `lanes`
and labelled as trial seeds, not approved production cadence. There is one
maximum of four concurrent source requests across the lanes.

The live trial performed **28 requests in seven actual bounded slots**, covered
25 distinct classes and **revisited three classes when due**. It recorded
**11 actual interval/lane replans** based on validated source changes/statuses.
The longest observed slot was **4.266
seconds**, within the 25-second trial budget. Each request was limited to an
18-second timeout. Full baseline capture and lane/slot dispatch are separately
logged; no legacy A–D runtime integration is implied.

For example, observed source changes shortened current-class trial intervals
from 90 to 60 seconds and today's coverage intervals from 300 to 120 seconds.
A completed status was also reclassified into completed-correction coverage.
All changes have before/after state and a reason in the saved trial evidence;
the latest state, due time, interval, revision and reason are persisted in
`work-items`. Successful unchanged observations advance successful-read time,
while failure handling preserves the prior successful timestamp and fingerprint.

The first bounded segment stopped at its 24-request allowance before recurrence
could be observed: source reads passed, but that segment's recurrence criterion
failed. Its original evidence is retained in `adaptive/trial-initial-segment.json`.
The trial resumed from its saved state and completed the repeat/replan checks
without replaying the successful segment. Final `adaptive/trial.json` is PASS.
This is evidence of bounded resumption and actual due repeats, not proof of an
unattended scheduler running indefinitely.

Five offline planner tests passed: unchanged-response interval expansion,
change-driven promotion, failure preservation/backoff, continued completed-class
coverage, and bounded dispatch excluding in-flight work with deadline escalation.
No failures or entry removals were manufactured in Airtable. Real source reads
had zero errors; removal/drop behavior was not exercised by a natural removal in
this live trial. The trip `record-status` field supports retaining dropped rows
on a successful complete class response instead of deleting history.

## Persistence and readback evidence

- `schema-created.json`, `schema-final.json`: actual table and field IDs.
- `record-map-baseline.json`, `record-map-final.json`: actual stable-key → record-ID mappings.
- `baseline/results.json`, `baseline/source/`: fresh source receipts and sanitized captures.
- `baseline-readback.json`: all 3,045 initial records across 18 tables passed field/link readback.
- `adaptive/trial.json`: 28 live refresh observations and the saved planner states.
- `latest-graph.json`: normalized current expected graph, including adaptive updates/results.
- `final-readback.json`: all 3,903 records across 19 tables passed full authored-field/link checks.
- `control-readback.json`: final run status and 28 adaptive collection receipts read back as verified.

Readback compared record IDs, linked targets, values, JSON source bodies and
numeric/date precision. It did not infer success from record counts or a process
exit alone. Existing stable record IDs were retained through refresh; there are
no duplicate stable keys. Updated class trip counts still total 794 active trips,
and all 794 result projections link to their corresponding trip/class/entry.

## Execution boundary

**CONFIRMED:** fresh complete-show acquisition, linked-table persistence/readback,
actual bounded adaptive refresh/replanning, and stateful resumption in this base.
**UNVERIFIED:** sustained operation, peak winter load, show rollover, deployment
on the user's Windows host, integration with production A–D slots, and downstream
Webflow publication. Those were not fabricated to make the proof appear broader.

This workspace executed an isolated bounded trial. It did not install or enable
a permanent Windows task, background service or Airtable automation. A production
recurring runner still requires the actual existing Windows execution surface,
its deployed cadence/source budget and its authorized integration point. No
claim is made that the stored `next-due` values themselves trigger execution.

## Implementation files

- `wef-schedules/tests/decoded-day-ring-class.py`: existing isolated acquisition,
  extended with optional sanitized captures.
- `build-wef-data-graph.py`: baseline linked model and initial lane/work assignment.
- `wef-data-adaptive-trial.py`: bounded due-driven source trial and five planner tests.
- `build-wef-data-delta.py`: same-record refresh, trip lifecycle and result projection.
- `prepare-wef-data-batches.py`: bounded connector upload/readback batches.

Airtable writes and full readbacks used the authenticated Airtable connector in
this session with the exact destination base ID and actual schema IDs. No PAT was
extracted or guessed. Source/test artifacts are kept under this evidence directory.
